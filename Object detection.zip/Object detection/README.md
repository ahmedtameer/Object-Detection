# yolo_objectDetection_imagesCPU
YOLO Object Detection on Images on a CPU
